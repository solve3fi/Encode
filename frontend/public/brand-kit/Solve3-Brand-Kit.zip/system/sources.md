# Source register and design decisions

Inspected 21 September 2026.

1. https://solve3.fi/ — primary visual and product reference. Inspected in the browser and through public page content.
2. https://solve3.fi/assets/images/solve-logo.svg — original 161 × 44 vector logo. Copied unchanged to `logos/solve3-original.svg`. The icon-only assets isolate its original symbol; monochrome derivatives replace fills.
3. Public CSS files linked from the inspected homepage — saved in `source/`. Semantic color, spacing, radius and typography tokens are transcribed in `system/tokens.json` and `system/tokens.css`.
4. https://docs.solve3.fi/overview/flywheel — conceptual background. Uses legacy SLV/veSLV terminology and stronger growth claims; neither is carried into proposed promotional copy.
5. https://github.com/google/fonts/tree/main/ofl/bevietnampro — supplied font family. The font license is included in `fonts/OFL.txt`.

## Observed identity

Base #070711; sunken #0D0C1B; raised #121026; overlay #181726. Accent #685DF7; hover #7C7CFD; muted accent #201070. Primary text #F6F5F9; secondary #ADA8C3; tertiary #827E90. Strong border #454365; subtle border #6065971A. Information cyan #58D7FF; positive #56E7A4; caution #FFBE5C; negative #E44F4F.

Logo gradient: #7544FF to #A491FF. Original coordinates: (11.2285, 4.92428) to (28.8192, 35.5221), in the SVG's user space. Second stop offset: 0.968831. Preserve the source gradient rather than substituting an arbitrary angle.

The live CSS defines a Funnel display token, but computed headings in the inspected browser resolve to Be Vietnam Pro. This kit follows that visible rendered result. Body text also resolves to Be Vietnam Pro. The campaign scale is proposed; website token sizes are preserved separately for reference.

## Proposed extensions

Clear space, minimum logo size, social margins, co-brand composition, brand voice and campaign messaging are recommendations created for this kit. Large, low-opacity symbols in backgrounds are a proposed graphic treatment. The live homepage is predominantly flat and restrained; the kit does not invent a broad multicolor gradient system.

## Source conflicts and limits

The current homepage uses SOLV3/veSOLV3 and describes pending locking/voting. The older documentation uses SLV/veSLV. Current website naming and status take precedence. The kit does not verify smart-contract behavior or turn legacy growth claims into promises.

The source website and docs are the supplied references; no unseen prior handoff or source file is assumed. Platform canvas sizes are production recommendations and must be previewed against the actual upload crop.
