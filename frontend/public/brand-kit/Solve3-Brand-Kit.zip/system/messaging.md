# Solve3 messaging library

Proposed copy, grounded in the live website's naming and status on 21 September 2026. Recheck availability before publication.

## Naming

Write **Solve3** in running text. The original lowercase `solve3` artwork is the wordmark. Use **SOLV3** for the token and **veSOLV3** for voting power. The legacy docs' SLV/veSLV wording is not used in this kit.

## Short description

Solve3 brings token exchange, liquidity and future voting participation together on Solana.

## Profile bio

Explore liquidity and token exchange on Solana. Devnet sandbox. Learn about future veSOLV3 participation at solve3.fi.

## Community welcome

Welcome to the Solve3 community. Explore the protocol, ask questions and learn how liquidity and participation connect. The current app is a devnet sandbox; test tokens have no monetary value. Start with solve3.fi for current product status.

## Launch-neutral social captions

**Liquidity education:** Liquidity makes token exchange possible. Explore the pools in Solve3's devnet sandbox and learn how participation works. solve3.fi

**Voting education:** Pool incentives are part of Solve3's participation model. Learn how future veSOLV3 voting is intended to work, and review the conditions before participating. Locking and voting are coming soon. solve3.fi

**Epoch education:** Timing matters in a voting system. Review the current epoch schedule and participation conditions on Solve3 before making a plan. Voting is coming soon. solve3.fi

## Partnership copy template

Solve3 × [Partner]

[Describe the specific collaboration in one concrete sentence.]

[Explain what the collaboration enables and who it helps.]

[State availability, network and any relevant conditions.]

[Add one verified destination link.]

Replace all bracketed fields and verify the partner's identity and agreed scope before use. Do not imply a partnership from a logo placement alone.

## Vocabulary

- **Liquidity:** assets supplied to support exchange in a pool.
- **Voting:** allocating voting power to eligible gauges, subject to protocol rules.
- **Gauge:** a pool-associated mechanism used for voting and incentive allocation.
- **Emissions:** token distribution directed by protocol mechanics. Distinguish this from trading fees.
- **Rewards:** always identify the recipient, source and conditions. Do not imply a fixed return.
- **Epoch:** the protocol's recurring accounting and participation interval.
- **Flywheel:** a conceptual feedback cycle connecting liquidity, trading activity, incentives and participation. It is not a guarantee of growth.

## Voice and copy rules

Use short sentences, clear verbs and concrete outcomes. Keep one principal message per graphic and one next step per caption. Explain unfamiliar terms before using abbreviations. Say when a feature is pending. Avoid guaranteed returns, effortless income and unlimited growth language. Avoid invented statistics and unverified adoption claims.
