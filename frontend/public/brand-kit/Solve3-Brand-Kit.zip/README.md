# Solve3 brand kit

Built 21 September 2026 from the live website and public documentation.

Start with **Solve3-Brand-Guide.pdf** (11 pages) and **Solve3-Quick-Reference.pdf** (one page).

## What's included

- `logos/`: unchanged original SVG plus full-color, white and dark lockups and symbols. PNG versions have transparent backgrounds. Primary white-wordmark lockups belong on dark surfaces.
- `social/`: 11 compositions, each as a ready-to-upload PNG, an outlined SVG and a text-editable SVG. Includes X, Discord, Telegram, landscape, square, portrait, epoch education and partnership formats.
- `fonts/`: Be Vietnam Pro Regular, Medium, SemiBold and Bold, with its SIL Open Font License.
- `system/`: observed tokens as JSON/CSS, messaging copy and source notes.
- `guide-pages/`: vector guide page artwork.
- `source/`: the original downloaded logo and the website CSS snapshot used to recover tokens.

## Editing

Install the supplied fonts before editing `.editable.svg` files in a vector editor that supports SVG text. Open the outlined `.svg` version when exact appearance matters and font installation is unavailable. The outlined version has editable shapes, but text is no longer directly editable. Export to PNG at the original dimensions after editing. The bundled PNGs are rendered with the supplied font shapes.

The source logo is not recreated with a typeface. Keep its geometry and proportions. The guide's spacing, minimum sizes, campaign layouts and voice rules are **proposed extensions**, not claimed official standards.

## Asset sizes and intended use

| File | Pixels | Use |
|---|---:|---|
| x-header | 1500 × 500 | X profile banner; key text sits away from the lower-left avatar area |
| x-avatar | 400 × 400 | X circular profile crop |
| discord-icon | 512 × 512 | Discord server icon |
| discord-banner | 960 × 540 | Community banner artwork; crop to the actual server slot if needed |
| telegram-avatar | 512 × 512 | Telegram circular group/profile crop |
| telegram-welcome | 1280 × 720 | Welcome message image |
| social-landscape | 1600 × 900 | General announcement |
| social-square | 1080 × 1080 | Future voting education |
| social-portrait | 1080 × 1350 | Portrait feed post |
| partnership-template | 1600 × 900 | Co-brand template; replace ALL bracketed fields |
| epoch-education | 1600 × 900 | Protocol education |

These are delivery canvas sizes, not a claim that every platform requires those dimensions. Preview platform crops and check the available account/server features before publishing.

## Current product context

The inspected site calls the app a devnet sandbox and marks locking/voting as coming soon. Templates retain that distinction. Recheck the live product before publication. The partnership asset intentionally contains placeholders and is not ready to announce a real partnership.

Fonts are provided under the included license. Solve3's recovered marks remain Solve3 brand assets; this kit does not confer trademark ownership or grant third-party endorsement. The social extension artwork is newly composed for this request.

## Production notes

PDFs contain vector artwork with outlined lettering for stable appearance. They are intended as visual guides; use editable SVGs and the messaging markdown for copy changes. Colors are specified in sRGB; no CMYK conversion or printer proof is included.
